﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Mathmatics
{
    public class HalfPlane
    {
        public float distance;
        Vector2 normal;

        public HalfPlane(float distance, Vector2 normal)
        {
            this.distance = distance;
            this.normal = normal;
        }
    }
}
