﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Scene.Objects
{
    public interface IParticle:IMovable,IMass,IParticleCollider
    {
    }
}
