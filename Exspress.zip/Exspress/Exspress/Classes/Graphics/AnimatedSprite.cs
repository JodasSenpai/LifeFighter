﻿using LifeFighter.Classes.Graphics;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Graphics
{
    public class AnimatedSprite
    {
        public ArrayList frames;
        public TimeSpan duration;
        public bool looping;
        public ArrayList frameStartSort;

        public AnimatedSprite()
        {
            frames = new ArrayList();
        }
        
        public void SetWithDuration(TimeSpan duration)
        {
            this.duration = duration;
            
        }

        public void SetWithLoopDuration(TimeSpan duration)
        {
            this.duration = duration;
            looping = true;
        }

        public void AddFrame(AnimatedSpriteFrame frame)
        {
            frames.Add(frame);            
        }

        public Sprite SpriteAtTime(TimeSpan time)
        {
            AnimatedSpriteFrame frame;
            AnimatedSpriteFrame nextFrame;

            if (looping) {
		        int loops = (int)Math.Floor((time.TotalMilliseconds / duration.TotalMilliseconds));
                TimeSpan sub = new TimeSpan(0, 0, 0, (int)Math.Floor(loops * duration.TotalMilliseconds));
                time.Subtract(sub);
                
            }
	
	        if (time >= duration) {
		        // Animation has finished.
		        return null;
	        } 
	
	        for (int i = 0; i< frames.Count - 1; i++) {
		        nextFrame =(AnimatedSpriteFrame) frames[i + 1];
		        if (nextFrame.start > time) {
			        frame = (AnimatedSpriteFrame)frames[i];
			        return frame.sprite;
		        }
	        }
	
	        // Return last frame.
	        frame = (AnimatedSpriteFrame)frames[frames.Count - 1];
	        return frame.sprite;
        }
    }
    
}
