﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace LifeFighter.Classes.Graphics
{
    public class Sprite
    {
        public Texture2D texture;
        public Vector2 origin;
        public Rectangle sourceRectangle;
        public float scale;
        public float layerDepth;
        public SpriteEffects spriteEffect;
        public float rotation;
    }
}
