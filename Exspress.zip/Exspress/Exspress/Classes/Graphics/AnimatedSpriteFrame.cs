﻿using LifeFighter.Classes.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Graphics
{
    public class AnimatedSpriteFrame
    {
        public Sprite sprite;
        public TimeSpan start;

        public AnimatedSpriteFrame(Sprite sprite, TimeSpan start)
        {
            this.sprite = sprite;
            this.start = start;        
        }

    }
}
