﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Physics
{
    public class CollisionAlgorithm : ICollisionAlgorithm
    {
        public void CollisionBetween(object item1, object item2)
        {
            Collision.CollisionBetween(item1, item2, this);
        }


        public virtual bool DetectCollisionBetween(object item1, object item2)
        {
            return false;
        }

        public virtual void ResolveCollisionBetween(object item1, object item2)
        {
            
        }
    }
}
