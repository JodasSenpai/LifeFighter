﻿using Exspress.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exspress.Classes.Physics
{
    public class Collision
    {


        public static void CollisionBetween(object item1, object item2)
        {
            CollisionBetween(item1,item2,true);
        }

        public static void CollisionBetween(object item1 ,object item2,bool recurseInverse)
        {

            IParticleCollider item1Particle = (item1 is IParticleCollider) ? (IParticleCollider)item1 : null;
            IAARectangleCollider item1AARectangle = (item1 is IAARectangleCollider) ?(IAARectangleCollider) item1 : null;

            IParticleCollider item2Particle = (item2 is IParticleCollider) ? (IParticleCollider)item2 : null;
            IAARectangleCollider item2AARectangle = (item2 is IAARectangleCollider) ? (IAARectangleCollider)item2 : null;
            //id<IAAHalfPlaneCollider> item2AAHalfPlane = [item2 conformsToProtocol:@protocol(IAAHalfPlaneCollider)] ? item2 : nil;


            if (item1Particle != null && item2Particle != null) {
                ParticleParticleCollision instance = new ParticleParticleCollision();
                instance.CollisionBetween(item1Particle,item2Particle);
		        return;
	        }
            /* else if (item1Particle && item2AAHalfPlane) {
		        [ParticleAAHalfPlaneCollision collisionBetween:item1Particle and:item2AAHalfPlane];
		        return;
	        }*/
            else if (item1Particle != null && item2AARectangle != null) {
                ParticleAARectangleCollision instance = new ParticleAARectangleCollision();
                instance.CollisionBetween(item1Particle, item2AARectangle);
                return;

            }/* else if (item1AARectangle && item2AAHalfPlane) {
		        [AARectangleAAHalfPlaneCollision collisionBetween:item1AARectangle and:item2AAHalfPlane];
		        return;
           
            }
            else if (item1AARectangle != null && item2AARectangle != null) {
		        [AARectangleAARectangleCollision collisionBetween:item1AARectangle and:item2AARectangle];                
		        return;
	        }
	        */
            if (recurseInverse) {
		        CollisionBetween(item2,item1,false);
	        }
        }

        public static void CollisionBetween(object item1, object item2,CollisionAlgorithm collisionAlgorithm)
        {
            if (collisionAlgorithm.DetectCollisionBetween(item1, item2)) {
                
                if (Collision.ShouldResolveCollisionBetween(item1, item2))
                {
                    collisionAlgorithm.ResolveCollisionBetween(item1, item2);
                    Collision.ReportCollisionBetween(item1, item2);
                }
            }
            
        }
        public static bool ShouldResolveCollisionBetween(object item1, object item2)
        {
            ICustomCollider customCollider1 = item1 is ICustomCollider ? (ICustomCollider)item1 : null;
            ICustomCollider customCollider2 = item2 is ICustomCollider ? (ICustomCollider)item2 : null;

            bool result = true;

            if (customCollider1 != null) {
                result &= customCollider1.CollidingWithItem(item2);
            }
	
	        if (customCollider2 != null) {
                result &= customCollider2.CollidingWithItem(item1);
            }
	
	        return result;
        }

        public static void ReportCollisionBetween(object item1, object item2)
        {
                ICustomCollider customCollider1 = item1 is ICustomCollider ? (ICustomCollider)item1 : null;
                ICustomCollider customCollider2 = item2 is ICustomCollider ? (ICustomCollider)item2 : null;
                
                if(customCollider1 != null) {
                    customCollider1.CollidedWithItem(item2);
                }
	
	            if (customCollider2 != null) {
		            customCollider2.CollidedWithItem(item1);
	            }
        }


        public static void RelaxCollisionBetween(object item1, object item2, Vector2 relaxDistance)
        {
	        // We have to ask, how far we move each item. The default is each half way, but we try to take
	        // the mass of the colliders into account, if items have mass.
	        float relaxPercentage1 = 0.5f;
	        float relaxPercentage2 = 0.5f;

            // Determine mass of the colliders. If an item has no mass it is considered static,
            // so we should move only the other one. If both have mass, we move them reciprocal to their mass.
            // So a heavier item will move a little and a lighter item more.
            IMass itemWithMass1 = item1 is IMass ? (IMass)item1 : null;
            IMass itemWithMass2 = item2 is IMass ? (IMass)item2 : null;
            IPosition itemWithPosition1 = item1 is IPosition ? (IPosition)item1 : null;
            IPosition itemWithPosition2 = item2 is IPosition ? (IPosition)item2 : null;

            if (itemWithMass1 != null && itemWithMass2 != null) {
                float mass1 = itemWithMass1.Mass;
                float mass2 = itemWithMass2.Mass;
                relaxPercentage1 = mass2 / (mass1 + mass2);
                relaxPercentage2 = mass1 / (mass1 + mass2);
            } else if (itemWithMass1 != null) {
                relaxPercentage1 = 1;
                relaxPercentage2 = 0;
            } else if (itemWithMass2 != null) {
                relaxPercentage1 = 0;
                relaxPercentage2 = 1;
            } else {
                // No item has mass, do the same logic, but with positions.
                if (itemWithPosition1 != null && !(itemWithPosition2 != null))
                {
                    relaxPercentage1 = 1;
                    relaxPercentage2 = 0;
                }
                else if (!(itemWithPosition1 != null) && itemWithPosition2 != null)
                {
                    relaxPercentage1 = 0;
                    relaxPercentage2 = 1;
                }
            }
	
	        // Now we need to turn the percentages into real distances.	
	
	        if (itemWithPosition1 != null) {
                itemWithPosition1.Position -= Vector2.Multiply(relaxDistance, relaxPercentage1);        
            }
	        if (itemWithPosition2 != null) {
                itemWithPosition2.Position -= Vector2.Multiply(relaxDistance, relaxPercentage2);
            }
        }

        public static void ExchangeEnergyBetween(object item1 , object item2, Vector2 collisionNormal)
        {
            // We calculate exchange of energy in a collision with respect to items' momentum. Momentum is mass times
            // velocity so the items need to conform both to IMass and IVelocity. If one of the items does not, it's
            // considered as though there is a collision with a static object.
            IVelocity itemWithVelocity1 = item1 is IVelocity ? (IVelocity)item1 : null;
            IVelocity itemWithVelocity2 = item2 is IVelocity ? (IVelocity)item2 : null;
        

       
            Vector2 velocity1 = itemWithVelocity1 != null ? itemWithVelocity1.Velocity : Vector2.Zero;

            Vector2 velocity2 = itemWithVelocity2 != null ? itemWithVelocity2.Velocity : Vector2.Zero;

            // In a collision, energy is exchanged only along the collision normal, so we take into account only
            // the speed in the direction of the normal.
            float speed1 = velocity1 != Vector2.Zero ? Vector2.Dot(velocity1, collisionNormal) : 0;
	        float speed2 = velocity2 != Vector2.Zero ? Vector2.Dot(velocity2, collisionNormal) : 0;
            float speedDifference = speed1 - speed2;
	
	        // Make sure the objects are coming towards each other. If they are coming together the collision has already been delt with.
	        if (speedDifference < 0) {
                return;
            }

            // We can now calculate the impact impulse (the change of momentum). We take into account the cooeficient
            // of restitution which controls how elastic the collision is. We use a simplified model in which the total
            // COR is just the multiplication of coeficients of both items.

            ICoefficientOfRestitution itemWithCOF1 = item1 is ICoefficientOfRestitution ? (ICoefficientOfRestitution)item1 : null;
            ICoefficientOfRestitution itemWithCOF2 = item2 is ICoefficientOfRestitution ? (ICoefficientOfRestitution)item2 : null;

            float cor1 = itemWithCOF1 != null ? itemWithCOF1.CoefficientOfRestitution : 1.0f;

            float cor2 = itemWithCOF2 != null ? itemWithCOF2.CoefficientOfRestitution : 1.0f;
            float cor = cor1 * cor2;
	
	        // We prepare mass inverses. If the object has no mass we consider it is static, which is the same as having
	        // infinite mass. The inverse will then be zero.
            IMass itemWithMass1 = item1 is IMass ? (IMass)item1 : null;
            IMass itemWithMass2 = item2 is IMass ? (IMass)item2 : null;
            float mass1inverse = itemWithMass1 != null ? 1.0f / itemWithMass1.Mass : 0;
            float mass2inverse = itemWithMass2 != null ? 1.0f / itemWithMass2.Mass : 0;

            // We derive the formula for the impact as the change of momentum.
            float impact = -(cor + 1) * speedDifference / (mass1inverse + mass2inverse);
	
	        // If we divide the impact with item's mass we get the change in speed. We apply it
	        // along the collisions normal. We only do this for non-static items.
	        if (mass1inverse > 0 && itemWithVelocity1 != null) {

                itemWithVelocity1.Velocity += Vector2.Multiply(collisionNormal,impact * mass1inverse);
            }
	
	        if (mass2inverse > 0 && itemWithVelocity2 != null) {
		        itemWithVelocity2.Velocity -= Vector2.Multiply(collisionNormal,impact * mass2inverse);
	        }	
        }

    }
    
}
