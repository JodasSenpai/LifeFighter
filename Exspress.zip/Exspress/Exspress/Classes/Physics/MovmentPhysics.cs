﻿using Exspress.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Physics
{
    public class MovmentPhysics
    {
        public static void SimulateMovmentOn(object item, TimeSpan elapsed)
        {
            if (item is IMovable)
            {
                IMovable movable = (IMovable)item;
                if (elapsed.TotalMilliseconds != 0 && movable.Velocity != Vector2.Zero)
                {
                    movable.Position += Vector2.Multiply(movable.Velocity, (float)elapsed.TotalMilliseconds);
                }
            }
            
        }
        
    }
}
