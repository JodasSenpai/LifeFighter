﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Physics
{
    interface ICollisionAlgorithm
    {
        void CollisionBetween(object item1, object item2);
        bool DetectCollisionBetween(object item1, object item2);
        void ResolveCollisionBetween(object item1, object item2);
    }
}
