﻿using Exspress.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exspress.Classes.Physics
{
    public class ParticleParticleCollision : CollisionAlgorithm
    {

        public override bool DetectCollisionBetween(object item1, object item2)
        {
            IParticleCollider particle1 = (IParticleCollider)item1;
            IParticleCollider particle2 = (IParticleCollider)item2;
            float distanceBetweenParticles = Vector2.Subtract(particle1.Position, particle2.Position).Length();

            //System.Diagnostics.Debug.WriteLine(String.Format("distance: {0}", distanceBetweenParticles));
            //System.Diagnostics.Debug.WriteLine(String.Format("radius1: {0},radius2: {1}, sum {2}", particle1.Radius, particle2.Radius, particle1.Radius + particle2.Radius));
            return distanceBetweenParticles < particle1.Radius + particle2.Radius;
        }

        public override void ResolveCollisionBetween(object item1, object item2)
        {
            IParticleCollider particle1 = (IParticleCollider)item1;
            IParticleCollider particle2 = (IParticleCollider)item2;
            // RELAXATION STEP

            // First we relax the collision, so the two objects don't collide any more.
            // We need to calculate by how much to move them apart. We will move them in the shortest direction
            // possible which is simply the difference between both centers.
            Vector2 positionDifference = Vector2.Subtract(particle2.Position, particle1.Position);
            float collidedDistance = positionDifference.Length();
            float minimumDistance = particle1.Radius + particle2.Radius;
            float relaxDistance = minimumDistance - collidedDistance;

            Vector2 collisionNormal = collidedDistance != 0 ? Vector2.Normalize(positionDifference) : Vector2.UnitX;
            Vector2 relaxDistanceVector = Vector2.Multiply(collisionNormal, relaxDistance);
            Collision.RelaxCollisionBetween(particle1, particle2, relaxDistanceVector);

            // ENERGY EXCHANGE STEP

            // In a collision, energy is exchanged only along the collision normal.
            // For particles this is simply the line between both centers.
            Collision.ExchangeEnergyBetween(particle1,particle2,collisionNormal);
        }
    }
    
}
