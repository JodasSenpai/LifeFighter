﻿using LifeFighter.Classes.Components;
using LifeFighter.Classes.Enemies;
using LifeFighter.Classes.Players;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes.Scene;
using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes
{
    class Gameplay : GameComponent        
    {
        public Level level;
        static public HumanPlayer mainPlayer;
        static public Control control;
        public int frogsCount;
        Game game;
        GameRenderer renderer;
        GuiRenderer guiRenderer;
        Director currentDirector;
        PhysicsEngine physics;
        SoundEngine sound;
        public Gameplay(Game game, Level level) : base(game)
        {
            this.game = game;
            this.level = level;
            this.frogsCount = level.frogs.Count;
        }



        public void SingleplayerMode()
        {
            //Create players
            mainPlayer = level.human;
            //Create control
            control = new Control();
            Start();
            
        }



        public override void Update(GameTime gameTime)
        {
            
            mainPlayer.Update(gameTime);
            control.Update(gameTime);
            
            
            if (!renderer.active)
            {
                guiRenderer.active = true;
                guiRenderer.MyUpdate(renderer);
            }
            else
            {
                guiRenderer.active = false;
                renderer.MyUpdate();
            }
            
            
            
            if (level.scene.items.Count - level.frogs.Count == -1) {
                foreach (FrogEnemy item in level.frogs)
                {
                    item.Reset();
                    level.scene.addItem(item);
                }
            }
            
            foreach (FrogEnemy item in level.frogs)
            {
                if (level.scene.items.Contains(item)) {
                    item.Update(gameTime);
                    if (!item.alive)
                    {
                        level.scene.items.Remove(item);
                    }
                }
            }
            currentDirector.camera.Update(mainPlayer.position);
            currentDirector.miniMapCamera.Update(mainPlayer.position);
            base.Update(gameTime);
        }

        void Start()
        {
            
            game.Components.Add(level);

            currentDirector = new Director(game);



            renderer = new GameRenderer(game, level, mainPlayer, currentDirector.camera, currentDirector.miniMapCamera);
            game.Components.Add(renderer);

            guiRenderer = new GuiRenderer(game);
            game.Components.Add(guiRenderer);

            physics = new PhysicsEngine(game,level,mainPlayer);
            game.Components.Add(physics);

            //sound = new SoundEngine(game);
            //game.Components.Add(sound);


        }

        
    }
}
