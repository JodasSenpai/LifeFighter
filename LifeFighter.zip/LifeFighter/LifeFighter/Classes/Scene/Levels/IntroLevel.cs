﻿using LifeFighter.Classes.Enemies;
using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LifeFighter.Classes.Scene.Levels
{
    public class IntroLevel : Level
    {
        
        public IntroLevel(Game game):base(game)
        {

            readMap = new ReadMap();
            readMap.ReadMapFromJson(@"..\\..\\..\\..\\/Resources/map/myFirstMap.json");
            human = new HumanPlayer(new Vector2(0, 0));
            scene.addItem(human);

            
            foreach (var item in readMap.GetObjects())
            {
                scene.addItem(item);
            }
            foreach (var item in base.scene.items)
            {
                if(item is FrogEnemy)
                {
                    base.frogs.Add(item);
                }
            }
           
            layers = readMap.GetLayers();
            
            
        }
    }
}
