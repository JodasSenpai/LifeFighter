﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Levels
{
    public class Map
    {
        public int height { get; set; }
        public int width { get; set; }
        public bool infinite { get; set; }
        public Layers[] layers { get; set; }
        public int tileheight { get; set; }
        public int tilewidth { get; set; }
        public Tiles[] tilesets { get; set; }

    }
}
