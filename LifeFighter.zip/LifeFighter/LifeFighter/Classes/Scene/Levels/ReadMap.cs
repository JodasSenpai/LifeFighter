﻿using LifeFighter.Classes.Enemies;
using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Levels
{
    public class ReadMap
    {
        public Map map;
        public void ReadMapFromJson(string file)
        {
            var json = File.ReadAllText(file);
            map = JsonConvert.DeserializeObject<Map>(json);            
        }


        public ArrayList GetLayers()
        {
            ArrayList layers = new ArrayList();
            
            
            foreach (Layers layer in map.layers)
            {
                Dictionary<Vector2, int> tiles = new Dictionary<Vector2, int>();
                if (layer.type == "tilelayer")
                {
                    
                    foreach (Chunks chunk in layer.chunks)
                    {
                        int index = 0;
                        for (int i = chunk.y; i < chunk.y + chunk.height; i++)
                        {
                            for (int j = chunk.x; j < chunk.x + chunk.width; j++)
                            {
                                if (chunk.data[index] != 0)
                                {
                                    tiles[new Vector2(j * map.tileheight, i * map.tilewidth)] = chunk.data[index];
                                }
                                index++;
                            }
                        }
                    }
                }
                layers.Add(tiles);
            }
            
            return layers;
        }
        public ArrayList GetObjects()
        {
            ArrayList layers = new ArrayList();


            foreach (Layers layer in map.layers)
            {
                
                if (layer.type == "objectgroup")
                {
                    foreach (Objects object_item in layer.objects)
                    {
                        if(object_item.type == "FrogEnemy"){
                            layers.Add(new FrogEnemy(new Vector2(object_item.x, object_item.y)));
                        }
                        else if (object_item.type == "Wall")
                        {
                            //System.Diagnostics.Debug.WriteLine(String.Format("Wall: w: {0}, h: {1}, x: {2},  y:{3}", object_item.width, object_item.height, object_item.x, object_item.y));
                            layers.Add(new Wall(new Vector2(object_item.x+ object_item.width/2, object_item.y+ object_item.height/2),object_item.width, object_item.height));
                        }
                        
                    }
                }
                
            }

            return layers;
        }



        public Sprite[] SetTileSprites(GraphicsDevice graphicDevice)
        {
            FileStream fileStream;
            Texture2D spriteAtlas;
            Sprite[] tilesSprites;
            int tilecount = 0;
            foreach (Tiles atlas in map.tilesets)
            {
                tilecount += atlas.tilecount;
            }
            tilesSprites = new Sprite[tilecount+1];
            int index = 1;
            
            
            foreach (Tiles atlas in map.tilesets)
            {
                fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/" + atlas.image, FileMode.Open);
                spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);

                double h = (atlas.imageheight / atlas.tileheight);
                int height = (int) Math.Floor(h);
                double w = (atlas.imagewidth / atlas.tilewidth);
                int width = (int)Math.Floor(w);
                
                int column = 0;
                int row = 0;
                
                
                for (int i = 1; i <= height; i++)
                {
                    column = 0;
                    for (int j = 1; j <= width; j++)
                    {
                        tilesSprites[index++] = new Sprite
                        {
                            texture = spriteAtlas,
                            sourceRectangle = new Rectangle(x: column, y: row, width: atlas.tilewidth, height: atlas.tileheight),
                            origin = new Vector2(x: 0, y: 0),
                            scale = 1f,
                            layerDepth = 1f,
                            spriteEffect = SpriteEffects.None
                        };
                        
                        column += atlas.tilewidth;
                    }
                    row += atlas.tileheight;
                }
                fileStream.Dispose();

            }
            
            return tilesSprites;
        }
    }
}
