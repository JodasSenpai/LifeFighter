﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Levels
{
    public class Layers
    {
        public Chunks[] chunks { get; set; }
        public Objects[] objects { get; set; }
        public int height { get; set; }
        public int width { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public int startx { get; set; }
        public int starty { get; set; }
        public string type { get; set; }
        public int x { get; set; }
        public int y { get; set; }
    }
}
