﻿using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using Exspress.Classes.Scene;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LifeFighter.Classes.Enemies;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Scene.Levels;

namespace LifeFighter.Classes.Scene
{
    public class Level : GameComponent
    {
        public SimpleScene scene;
        public HumanPlayer human;
        public ArrayList frogs;
        public ArrayList layers;
        public ArrayList tilesSprites;
        public ReadMap readMap;
        public bool end;
        public Level(Game game) : base(game)
        {
            end = false;
            this.scene = new SimpleScene();
            
            frogs = new ArrayList();
            
        }
    }     
    
}
