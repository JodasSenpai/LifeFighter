﻿using Exspress.Classes.Graphics;
using LifeFighter.Classes.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    class Mode:Position
    {
        public ArrayList sprites;
        public int direction;
        public TimeSpan time;
        public Sprite nonAnime;

        public Mode()
        {
            this.sprites = new ArrayList();
            time = new TimeSpan();
            nonAnime = null;
        }
        public Mode(ArrayList sprites)
        {
            this.sprites=sprites;
            time = new TimeSpan();
            nonAnime = null;
        }
        public Mode(Sprite nonAnime)
        {
            this.nonAnime = new Sprite
            {
                texture = nonAnime.texture,                
                sourceRectangle = new Rectangle(nonAnime.sourceRectangle.X, nonAnime.sourceRectangle.Y, nonAnime.sourceRectangle.Width, nonAnime.sourceRectangle.Height),
                origin = new Vector2(nonAnime.origin.X, nonAnime.origin.Y),
                scale = nonAnime.scale,
                layerDepth = nonAnime.layerDepth,
            }; 
        }
        public void SetTime(TimeSpan time) => this.time = time;
        public TimeSpan GetTime => time;
        public ArrayList GetSprites => sprites;

        public Sprite GetSprite()
        {
            if(nonAnime != null)
            {
                return nonAnime;
            }
            return ((AnimatedSprite)(sprites[direction])).SpriteAtTime(time);
        }
    }
}
