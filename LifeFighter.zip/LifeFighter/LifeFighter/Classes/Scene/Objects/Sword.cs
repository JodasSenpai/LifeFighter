﻿using Microsoft.Xna.Framework;
using Exspress.Classes.Scene;
using Exspress.Classes.Scene.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    public class Sword : IAARectangleCollider
    {
        public Vector2 position;
        //public Vector2 velocity;
        public float width;
        public float height;
        
        public bool collided;
        public Sword(Vector2 position)
        {

            //Velocity = new Vector2(0,0);
            collided = false;
            Position = position;
            /*
             * Left & Right
            Width = 95;
            Height = 30;
            */
            Width = 30;
            Height = 95;
        }

        //public Vector2 Velocity { get => this.velocity; set => this.velocity = value; }        
        public Vector2 Position { get => this.position; set => this.position = value; }
        public float Width { get => this.width; set => this.width = value; }
        public float Height { get => this.height; set => this.height = value; }

        public void DirectionChange(int dir)
        {
            if(dir == 0 || dir == 3)
            {
                Width = 30;
                Height = 95;
            }
            else
            {
                Width = 95;
                Height = 30;
            }
        }
    }
}
