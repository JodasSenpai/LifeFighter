﻿using Microsoft.Xna.Framework;
using Exspress.Classes.Scene;
using Exspress.Classes.Scene.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    public class NPC : IParticle
    {       

        public Vector2 position;
        public Vector2 velocity;
        public float mass;
        public float radius;
        
        public NPC(Vector2 position)
        {
        
            Velocity = new Vector2(0,0);
            Position = position;
            Mass = 8;
            Radius = 16;
        }

        public Vector2 Velocity { get => this.velocity; set => this.velocity = value; }
        public float Mass { get => this.mass; set => this.mass = value; }
        public float Radius { get => this.radius; set => this.radius = value; }
        public Vector2 Position { get => this.position; set => this.position = value; }

        
    }
}
