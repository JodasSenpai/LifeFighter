﻿using Exspress.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    public class Wall : IAARectangleCollider
    {
        public Vector2 position;
        
        public float width;
        public float height;


        public Wall(Vector2 position,float width,float height)
        {
            Position = position;
            Width = width;
            Height = height;
        }

             
        public Vector2 Position { get => this.position; set => this.position = value; }
        public float Width { get => this.width; set => this.width = value; }
        public float Height { get => this.height; set => this.height = value; }

    }
}
