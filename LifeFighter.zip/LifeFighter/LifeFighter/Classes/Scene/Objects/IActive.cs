﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Players
{
    interface IActive
    {
        bool Active { get; set; }
    }
}
