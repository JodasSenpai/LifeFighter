﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    interface ISprite
    {
        ArrayList SetUpAllSprites(GraphicsDevice graphicDevice);
        ArrayList GetCurrentlyUsedSprites();
        void SetUsedSprites(ArrayList list);        
        string Name { get; set; }
    }
}
