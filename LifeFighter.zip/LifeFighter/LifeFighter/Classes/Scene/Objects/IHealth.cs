﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Objects
{
    public interface IHealth
    {
        float Health { get;set; }
    }
}
