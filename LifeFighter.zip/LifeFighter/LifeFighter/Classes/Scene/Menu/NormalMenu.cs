﻿using Exspress.Classes.Scene;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Menu
{
    class NormalMenu
    {
        public SimpleScene scene;

        public NormalMenu()
        {
            scene = new SimpleScene();

            scene.addItem(new Button("Resume"));
            scene.addItem(new Button("Save"));
            scene.addItem(new Button("Settings"));
            scene.addItem(new Button("Quit"));
            
        }
    }
}
