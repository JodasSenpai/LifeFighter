﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Scene.Menu
{
    public class Button
    {
        public string value;
        public bool active;
        public Button(string value)
        {
            this.value = value;
            this.active = false;
        }
    }
}
