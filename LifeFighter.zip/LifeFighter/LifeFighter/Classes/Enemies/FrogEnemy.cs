﻿using Exspress.Classes.Scene.Objects;
using LifeFighter.Classes.Scene.Objects;
using LifeFighter.Classes;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Artificial.Everywhere;
using LifeFighter.Classes.Players.Human;
using Exspress.Classes.Graphics;
using System.Collections;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Players;

namespace LifeFighter.Classes.Enemies
{
    class FrogEnemy : Frog, ICustomCollider,IHealth,ISprite,IActive
    {
        public Vector2 distance;
        Vector2 movment;
        public bool active;
        float speed;
        public Sword sword;
        public bool moving;
        public bool attacked;
        public bool atck;
        public bool attackMode;
        public bool alive;
        public int direction;
        public int directionAttack;
        public TimeSpan timeMoving;
        public TimeSpan timeMovment;
        public TimeSpan timeWaiting;
        public TimeSpan timeWaitAttack;
        public TimeSpan timeAttack;
        TimeSpan timeAddMovment;
        TimeSpan timeAddWaitAttack;
        TimeSpan timeAddAttack;
        TimeSpan timeAddMoving;
        TimeSpan timeAddWait;
        Dictionary<int, Action> Dict;
        Dictionary<string, Mode> modeSprites;
        ArrayList currentlyUsedModesNames;
        
        int wait;
        int waitAttack;
        int move;
        
        Vector2 origPosition;
        float health;
        public float Health { get => health; set => health = value; }
        public float maxHealth;
        string name;
        public string Name { get => name; set => name = value; }
        public bool Active { get => active; set => active = value; }
        public FrogEnemy(Vector2 position) : base(position)
        {
            active = true;
            Name = "FrogEnemy";
            origPosition = new Vector2(position.X,position.Y);
            sword = new Sword(Position);
            currentlyUsedModesNames = new ArrayList();
            currentlyUsedModesNames.Add("frog");            
            wait = MyRandom.rnd.Next(1000, 10000);
            waitAttack = MyRandom.rnd.Next(1000, 10000);
            move = MyRandom.rnd.Next(1000, 10000);
            this.speed = 0.7f;            
            
            this.movment = base.position;
            timeWaitAttack = new TimeSpan(0, 0, 0, 0, 0);
            timeAttack = new TimeSpan(0, 0, 0, 0, 0);
            timeMovment = new TimeSpan(0, 0, 0, 0, 0);
            timeMoving = new TimeSpan(0, 0, 0, 0, 0);
            timeWaiting = new TimeSpan(0, 0, 0, 0, 0);
            timeAddMovment = new TimeSpan(0, 0, 0, 0, 100);
            timeAddMoving = new TimeSpan(0, 0, 0, 0, 100);
            timeAddWait = new TimeSpan(0, 0, 0, 0, 100);
            timeAddWaitAttack = new TimeSpan(0, 0, 0, 0, 100);
            timeAddAttack = new TimeSpan(0, 0, 0, 0, 200);
            moving = false;
            attackMode = false;
            atck = false;
            direction = 1;
            directionAttack = 0;
            Dict = new Dictionary<int, Action>();
            modeSprites = new Dictionary<string, Mode>();
            maxHealth = 100; 
            Health = maxHealth;
            alive = true;
            Dict.Add(0, value: MoveLeft);
            Dict.Add(1, value: MoveLeftUp);
            Dict.Add(2, value: MoveLeftDown);
            Dict.Add(3, value: MoveUp);
            Dict.Add(4, value: MoveRight);
            Dict.Add(5, value: MoveRightUp);
            Dict.Add(6, value: MoveRightDown);
            Dict.Add(7, value: MoveDown);

           
        }

        public void Update(GameTime gameTime)
        {
            if (!active)
            {
                return;
            }
            currentlyUsedModesNames.Clear();
            currentlyUsedModesNames.Add("frog");
           
            //sword.position = this.position - new Vector2(0, -7);
            if (attackMode)
            {
                currentlyUsedModesNames.Add("health");
                
                if (directionAttack == 3)
                {
                    sword.position = position - new Vector2(0, 7);
                }
                else if (directionAttack == 0)
                {
                    sword.position = position - new Vector2(0, -7);
                }
                else if (directionAttack == 1)
                {
                    sword.position = position - new Vector2(7, -7);
                }
                else if (directionAttack == 2)
                {
                    sword.position = position - new Vector2(-7, -7);
                }
                if (atck)
                {
                    if (sword.collided)
                    {
                        sword.DirectionChange(directionAttack);
                        currentlyUsedModesNames.Add("sword");
                        timeAttack += timeAddAttack;
                        if (timeAttack.TotalMilliseconds >= 3000)
                        {
                            atck = false;
                            timeAttack = new TimeSpan(0, 0, 0, 0, 0);
                        }
                        modeSprites["sword"].time = timeAttack;
                        modeSprites["frog"].time = new TimeSpan(0, 0, 0, 0, 0);
                    }
                }                                
                else if (timeWaitAttack.TotalMilliseconds < waitAttack)
                {
                    timeWaitAttack += timeAddWaitAttack;                    
                }
                else
                {
                    //waitAttack = MyRandom.rnd.Next(1000, 10000);
                    waitAttack = MyRandom.rnd.Next(1000, 1000);
                    timeWaitAttack = new TimeSpan(0, 0, 0, 0, 0);
                    moving = false;
                    atck = true;
                    sword.collided = false;
                }
               

            }
            else if (moving == false)
            {
                currentlyUsedModesNames.Add("health");
                if (timeWaiting.TotalMilliseconds < wait)
                {
                    timeWaiting += timeAddWait;
                }
                else
                {
                    moving = true;
                    direction = (direction + MyRandom.rnd.Next(1,8)) % 8;
                    timeWaiting = new TimeSpan(0, 0, 0, 0, 0);
                    wait = MyRandom.rnd.Next(10000, 20000);
                }
                modeSprites["frog"].time = new TimeSpan(0, 0, 0, 0, 0);
                
                
            }
            else
            {
                currentlyUsedModesNames.Add("health");
                timeMovment += timeAddMovment;
                if (timeMovment.TotalMilliseconds > 1900 || timeMovment.TotalMilliseconds < 100)
                {
                    timeAddMovment = timeAddMovment.Negate();
                    timeMovment += timeAddMovment;
                }
                
                if (timeMoving.TotalMilliseconds < move) {
                    
                    Dict[direction].Invoke();
                    
                    timeMoving += timeAddMoving;
                    
                }
                else
                {
                    moving = false;
                    timeMoving = new TimeSpan(0, 0, 0, 0, 0);
                    move = MyRandom.rnd.Next(1000, 2000);
                                        

                }
                modeSprites["frog"].time = timeMovment;
                

            }
            modeSprites["frog"].direction = directionAttack;
            modeSprites["frog"].position = position;
            
            modeSprites["sword"].direction = directionAttack;
            modeSprites["sword"].position = sword.position;

            modeSprites["health"].position = position + new Vector2(-42, -44);            
            modeSprites["health"].nonAnime.sourceRectangle.Width = (int)(Health / maxHealth * 98);
            distance = Vector2.Subtract(movment, base.position);

            

            if ((float)gameTime.ElapsedGameTime.TotalMilliseconds != 0)
            {
                base.Velocity = Vector2.Multiply(distance, 1.0f / ((float)gameTime.ElapsedGameTime.TotalMilliseconds));
            }

            if (Health <= 0)
            {
                //SoundEngine.soundEffects[1].CreateInstance().Play();
                alive = false;
                
                attackMode = false;
            }
        }






        void MoveRight()
        {
            movment = base.position + new Vector2(speed, 0);
            directionAttack = 2;
            
        }
        void MoveRightUp()
        {
            movment = base.position + new Vector2(speed, -speed);
            directionAttack = 2;
            
        }
        void MoveRightDown()
        {
            movment = base.position + new Vector2(speed, speed);
            directionAttack = 2;
            
        }
        void MoveLeft()
        {

            movment = base.position + new Vector2(-speed, 0);
            directionAttack = 1;
            

        }
        void MoveLeftUp()
        {

            movment = base.position + new Vector2(-speed, -speed);
            directionAttack = 1;
           

        }
        void MoveLeftDown()
        {

            movment = base.position + new Vector2(-speed, speed);
            directionAttack = 1;
            

        }
        void MoveUp()
        {

            movment = base.position + new Vector2(0, -speed);
            directionAttack = 3;
            

        }
        void MoveDown()
        {

            movment = base.position + new Vector2(0, speed);
            directionAttack = 0;
            
        }

        public bool CollidingWithItem(object item)
        {
            
            if (item is Sword)
            {
                if (!attacked)
                {
                    attackMode = true;

                    if (Gameplay.mainPlayer.directionAttack == 0)
                    {
                        directionAttack = 3;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 1)
                    {
                        directionAttack = 2;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 2)
                    {
                        directionAttack = 1;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 3)
                    {
                        directionAttack = 0;
                    }
                    moving = false;
                    attacked = true;
                    Health -= 1;

                }
                else
                {
                    attacked = false;
                }
                return false;
            }
            return true;
        }

        public void CollidedWithItem(object item)
        {


            if (item is Sword)
            {
                if (!attacked)
                {
                    attackMode = true;

                    if (Gameplay.mainPlayer.directionAttack == 0)
                    {
                        directionAttack = 3;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 1)
                    {
                        directionAttack = 2;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 2)
                    {
                        directionAttack = 1;
                    }
                    else if (Gameplay.mainPlayer.directionAttack == 3)
                    {
                        directionAttack = 0;
                    }
                    moving = false;
                    attacked = true;
                    Health -= 1;

                }
                else
                {
                    attacked = false;
                }
               
            }

        }
        public void Reset()
        {
            Health = maxHealth;
            alive = true;
        }
        public void Reposition(IParticle p)
        {
            moving = true;
            timeMovment += timeAddMovment;
            if (timeMovment.TotalMilliseconds > 1900 || timeMovment.TotalMilliseconds < 100)
            {
                timeAddMovment = timeAddMovment.Negate();
                timeMovment += timeAddMovment;
            }
            
            float x = this.position.X - p.Position.X;// if x > 0 -> on right side,if x < 0 -> on left side
            float y = this.position.Y - p.Position.Y;// if y > 0 -> on bottom side,if y < 0 -> on top side
            
            float distanceBetweenParticles = Vector2.Subtract(this.Position, p.Position).Length();
            this.speed *= 2;
            
            if (x > 50)
            {
                if (y > 50)
                {
                    Dict[1].Invoke();//leftUP
                }
                else if (y < -50)
                {
                    Dict[2].Invoke();//leftDown
                }
                else
                {
                    Dict[0].Invoke();//left
                }
            }
            else if (x < -50)
            {
                if (y > 50)
                {
                    Dict[5].Invoke();//rightUP
                }
                else if (y < -50)
                {
                    Dict[6].Invoke();//rightDown
                }
                else
                {
                    Dict[4].Invoke();//right
                }
            }
            else
            {
                if (y > 9)
                {
                    Dict[3].Invoke();//UP
                }
                else if (y < -9)
                {
                    Dict[7].Invoke();//Down
                }
                

            }

            
            this.speed /= 2;
            modeSprites["frog"].time = timeMovment;

        }
        public ArrayList GetCurrentlyUsedSprites()
        {
            int c = currentlyUsedModesNames.Count;
            ArrayList returnModes = new ArrayList(c);
            for(int i=0;i<c;i++)
            {
                returnModes.Add(modeSprites[(string)currentlyUsedModesNames[i]]);
            }
            return returnModes;
        }
        public void SetUsedSprites(ArrayList list)
        {
            
            modeSprites["frog"] = new Mode(((Mode)list[0]).sprites);
            
            modeSprites["sword"] = new Mode(((Mode)list[1]).sprites);

            modeSprites["health"] = new Mode(((Mode)list[2]).nonAnime);            
            modeSprites["health"].direction = 0;
            modeSprites["health"].time = new TimeSpan(0, 0, 0, 0, 0);


        }

        public ArrayList SetUpAllSprites(GraphicsDevice graphicDevice)
        {
            ArrayList list = new ArrayList();
            // need to create spritesheet for each uniqe enemy, might not be the optimal solution but it is a start
            FileStream fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/modernGuyTiles/modernGuySheet.png", FileMode.Open);
            Texture2D spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            /*
             * 
             * 0 -> frog sprite
             * 1 -> sword sprite
             * 2 -> health sprite
             *
             */

            //since i'll try to make spritesheet of all the sprites FrogEnemy uses, The number right now are INCORRECT!!!
            //add frogSprite <- 0
            fileStream.Dispose();
            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/frogTiles/lulstate/spritesheet.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            Mode frogSprite = new Mode();
            int row = 1;
            int column = 1;

            for (int i = 0; i <= 3; i++)
            {

                int time = 0;
                AnimatedSprite a = new AnimatedSprite();
                a.SetWithLoopDuration(new TimeSpan(0, 0, 0, 2, 0));
                frogSprite.sprites.Add(a);
                for (int j = 0; j <= 3; j++)
                {
                    Sprite sprite = new Sprite
                    {
                        texture = spriteAtlas,
                        sourceRectangle = new Rectangle(x: column, y: row, width: 32, height: 32),
                        origin = new Vector2(x: 15, y: 15),
                        scale = 1.5f,
                        layerDepth = 0.5f,
                        rotation = 0f,
                        spriteEffect = SpriteEffects.None
                    };
                    AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time));
                    ((AnimatedSprite)(frogSprite.sprites[i])).AddFrame(frame);
                    column += 34;
                    time += 500;
                }

            }
            fileStream.Dispose();

            list.Add(frogSprite);
            //INCORRECT numbers involve every sprite!!!!
            //add sword <- 1
            Mode swordSprite = new Mode();
            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/sword/sword3try/swordsheet.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            row = 1;
            column = 1;
            for (int i = 0; i <= 3; i++)
            {
                int time = 0;
                AnimatedSprite a = new AnimatedSprite();
                a.SetWithLoopDuration(new TimeSpan(0, 0, 0, 3, 0));
                swordSprite.sprites.Add(a);
                for (int j = 0; j <= 2; j++)
                {
                    float depth = 0.8f;
                    if (i == 0)
                    {
                        depth = 0.4f;
                    }
                    Sprite sprite = new Sprite
                    {
                        texture = spriteAtlas,
                        sourceRectangle = new Rectangle(x: column, y: row, width: 192, height: 154),
                        origin = new Vector2(x: 96, y: 78),
                        scale = 1,
                        rotation = 0f,
                        layerDepth = depth,
                    };
                    AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time));
                    ((AnimatedSprite)(swordSprite.sprites[i])).AddFrame(frame);

                    time += 1000;
                    column += 196;
                }


            }
            fileStream.Dispose();
            list.Add(swordSprite);

            //Add helthBar           

            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/frogTiles/enemy_health_bar.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);

            Sprite sprite2 = new Sprite
            {
                texture = spriteAtlas,
                sourceRectangle = new Rectangle(x: 1, y: 1, width: 98, height: 16),
                origin = new Vector2(x: 1, y: 1),
                scale = 1f,
                rotation = 0f,
                layerDepth = 0.7f,
            };
            Mode healthSprite = new Mode(sprite2);


            fileStream.Dispose();
            list.Add(healthSprite);


            return list;
        }
    }
}
