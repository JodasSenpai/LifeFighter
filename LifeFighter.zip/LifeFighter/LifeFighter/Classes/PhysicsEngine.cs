﻿using LifeFighter.Classes.Scene;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exspress.Classes.Physics;
using LifeFighter.Classes.Scene.Objects;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes.Enemies;

namespace LifeFighter.Classes
{
    public class PhysicsEngine : GameComponent
    {
        Level level;
        HumanPlayer mainPlayer;
        public PhysicsEngine(Game game, Level level,HumanPlayer mainPlayer) :base(game)
        {
            this.level = level;
            this.mainPlayer = mainPlayer;
        }

        public override void Update(GameTime gameTime)
        {

            MovmentPhysics.SimulateMovmentOn(mainPlayer,gameTime.ElapsedGameTime);
            //System.Diagnostics.Debug.WriteLine(String.Format("My coords: x: {0}, y: {1}", mainPlayer.Position.X, mainPlayer.Position.Y));
            foreach (object item in level.scene.items)
            {
                if (item is FrogEnemy f && f.active)
                {
                    
                    MovmentPhysics.SimulateMovmentOn(f, gameTime.ElapsedGameTime);
                    if (f.atck)
                    {
                        Collision.CollisionBetween(mainPlayer, f.sword);
                        if (!f.sword.collided)
                        {
                            f.Reposition(mainPlayer);
                        }
                    }
                    foreach (object item2 in level.scene.items)
                    {
                        if (item2 is FrogEnemy && item!=item2)
                        {
                            Collision.CollisionBetween(item, item2);
                        }
                    }
                }
            }
            foreach (var item in level.scene.items)
            {
                if (item is Frog){
                    Collision.CollisionBetween(item, level.human);
                    if (mainPlayer.attacked)
                    {
                        Collision.CollisionBetween(item, mainPlayer.sword);
                    }
                }
                if (item is Wall)
                {
                    Collision.CollisionBetween(item, level.human);
                }
            }
            
            base.Update(gameTime);
        }
    }
}
