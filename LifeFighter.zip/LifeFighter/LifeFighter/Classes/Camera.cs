﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes
{
    public class Camera
    {
        public Vector2 position;
        public float zoom;
        public float rotation;        
        public Matrix worldToScreen;
        public Matrix screenToWorld;
        public int viewportH;
        public int viewportW;


        public Camera(Viewport virport)
        {
            this.position = Vector2.Zero;
            this.zoom = 1.0f;
            this.rotation = 0;
            this.worldToScreen = Matrix.Identity;
            this.screenToWorld = Matrix.Identity;
            this.viewportW = virport.Width;
            this.viewportH = virport.Height;

        }

        public void Update(Vector2 pos)
        {
            this.position = pos;
            this.worldToScreen = Matrix.CreateTranslation(new Vector3(-pos,0.0f)) *
                                 Matrix.CreateRotationZ(this.rotation) *
                                 Matrix.CreateScale(new Vector3(this.zoom,this.zoom,1.0f)) *
                                 Matrix.CreateTranslation( (float)viewportW * 0.5f, (float)viewportH * 0.5f, 0.0f);
            this.screenToWorld = Matrix.Invert(worldToScreen);
        }
    }
}
