﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Scene;
using Exspress.Classes.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.IO;

using System.Collections;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes;
using Exspress.Classes.Scene.Objects;
using LifeFighter.Classes.Enemies;

using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using LifeFighter.Classes.Scene.Levels;
using LifeFighter.Classes.Players;
using Microsoft.Xna.Framework.Input;
using LifeFighter.Classes.Scene.Menu;

namespace LifeFighter.Classes.Components
{
    public class GuiRenderer : DrawableGameComponent
    {
        public bool active;
        public SpriteBatch spriteBatch;
        public SpriteFont spriteFont;
        Sprite menuSprite;
        Sprite buttonSprite;
        NormalMenu menu;
        Color color;
        int activeIndex;

        public TimeSpan timeWaiting;
        public TimeSpan timeAddWaiting;

        public GuiRenderer(Game game) : base(game)
        {
            timeWaiting = new TimeSpan(0, 0, 0, 0, 0);
            timeAddWaiting = new TimeSpan(0, 0, 0, 0, 100);
            active = false;
            
            menu = new NormalMenu();
            activeIndex = 0;
            ((Button)menu.scene.items[activeIndex]).active = true;
        }

        

        public void MyUpdate(GameRenderer renderer)
        {
            
            KeyboardState keyState = Keyboard.GetState();
            Keys[] pressedKeys = keyState.GetPressedKeys();
            
            if (pressedKeys.Any() && timeWaiting.TotalMilliseconds > 800)
            {
                timeWaiting = new TimeSpan(0, 0, 0, 0, 0);
                if (pressedKeys[0] == Keys.Enter )
                {
                    if (((Button)menu.scene.items[activeIndex]).value == "Resume")
                    {
                        renderer.active = true;
                        foreach (var item in renderer.level.scene.items)
                        {
                            if (item is IActive activeItem)
                            {
                                activeItem.Active = !activeItem.Active;
                            }
                        }
                    }
                    if (((Button)menu.scene.items[activeIndex]).value == "Quit")
                    {
                        Game.Exit();
                    }
                }
                if (pressedKeys[0] == Keys.S )
                {
                    ((Button)menu.scene.items[activeIndex]).active = false;
                    activeIndex++;
                    activeIndex %= menu.scene.items.Count;
                    ((Button)menu.scene.items[activeIndex]).active = active;
                }
                if (pressedKeys[0] == Keys.W )
                {
                    ((Button)menu.scene.items[activeIndex]).active = false;
                    activeIndex--;
                    if(activeIndex < 0)
                    {
                        activeIndex = menu.scene.items.Count-1;
                    }                    
                    ((Button)menu.scene.items[activeIndex]).active = active;
                }
                
            }
            if(timeWaiting.TotalMilliseconds <= 800)
            {
                timeWaiting += timeAddWaiting;
            }
            


        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = Game.Content.Load<SpriteFont>("test_font");
            FileStream fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/menu.png", FileMode.Open);
            Texture2D spriteAtlas = Texture2D.FromStream(GraphicsDevice, fileStream);

            menuSprite = new Sprite
            {
                texture = spriteAtlas,
                sourceRectangle = new Rectangle(x: 19, y: 17, width: 300, height: 608),
                origin = new Vector2(x: 150, y: 304),
                scale = 1f,
                layerDepth = 1f,
            };
            fileStream.Dispose();


            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/button.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(GraphicsDevice, fileStream);

            buttonSprite = new Sprite
            {
                texture = spriteAtlas,
                sourceRectangle = new Rectangle(x: 15, y: 525, width: 270, height: 50),
                origin = new Vector2(x: 135, y: 25),
                scale = 0.9f,
                layerDepth = 1f,
            };
            fileStream.Dispose();
        }


        public override void Draw(GameTime gameTime)
        {
            if (!active)
            {
                return;
            }
            spriteBatch.Begin(sortMode: SpriteSortMode.BackToFront);
            spriteBatch.Draw(
                                    texture: menuSprite.texture,
                                    position: new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2),
                                    sourceRectangle: menuSprite.sourceRectangle,
                                    color: Color.White,
                                    scale: menuSprite.scale,
                                    rotation: menuSprite.rotation,
                                    origin: menuSprite.origin,
                                    effects: SpriteEffects.None,
                                    layerDepth: menuSprite.layerDepth);
            float height = (GraphicsDevice.Viewport.Height / 2) - 368;
            float itemHeight = 508 / menu.scene.items.Count;
            
            for (int i = 1; i <= menu.scene.items.Count; i++)
            {
                spriteBatch.Draw(
                                    texture: buttonSprite.texture,
                                    position: new Vector2(GraphicsDevice.Viewport.Width / 2, height +(itemHeight*i)),
                                    sourceRectangle: buttonSprite.sourceRectangle,
                                    color: Color.White,
                                    scale: buttonSprite.scale,
                                    rotation: buttonSprite.rotation,
                                    origin: buttonSprite.origin,
                                    effects: SpriteEffects.None,
                                    layerDepth: buttonSprite.layerDepth);

                if (((Button)menu.scene.items[i - 1]).active)
                {
                    color = Color.DeepSkyBlue;
                }
                else
                {
                    color = Color.DimGray;    
                }
                spriteBatch.DrawString(spriteFont, String.Format("{0}", ((Button)menu.scene.items[i - 1]).value), new Vector2((GraphicsDevice.Viewport.Width / 2) - 50, height + (itemHeight * i) - 7), color);
            }
            

            spriteBatch.End();
        }

        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
    }
}
