﻿using LifeFighter.Classes.Graphics;
using LifeFighter.Classes.Scene;
using Exspress.Classes.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using System;
using System.Collections;
using LifeFighter.Classes.Players.Human;
using LifeFighter.Classes;
using Exspress.Classes.Scene.Objects;
using LifeFighter.Classes.Enemies;
using System.Collections.Generic;
using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using LifeFighter.Classes.Scene.Levels;
using LifeFighter.Classes.Players;
using Microsoft.Xna.Framework.Input;
using System.Linq;

namespace LifeFighter
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class GameRenderer : DrawableGameComponent
    {
        
        public SpriteBatch spriteBatch;
        public Level level;

        public Sprite[] tileSprites;
        public Sprite healthBarSprite;
        public Sprite tornadoIconSprite;
        public SpriteFont spriteFont;
        
        public Dictionary<string, ArrayList> SpritesForCurrentLevel;


        public HumanPlayer mainPlayer;
        public Vector3 playerMovment;
        public Camera camera;
        public Camera miniMapCamera;
        public BasicEffect spriteEffect;

        public bool active;

        public GameRenderer(Game game, Level theLevel, HumanPlayer mainPlayer,Camera camera, Camera miniMapCamera) :base(game)
        {
            this.mainPlayer = mainPlayer;
            this.playerMovment.Z = 0;
            this.level = theLevel;
            this.camera = camera;
            this.miniMapCamera = miniMapCamera;
            active = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        public void MyUpdate()
        {
            if (!active)
            {
                return;
            }
            KeyboardState keyState = Keyboard.GetState();           
            Keys[] pressedKeys = keyState.GetPressedKeys();
            if (pressedKeys.Any())
            {
                if (pressedKeys[0] == Keys.Escape)
                {
                    active = !active;
                    foreach (var item in level.scene.items)
                    {
                        if(item is IActive activeItem)
                        {
                            activeItem.Active = !activeItem.Active;
                        }
                    }
                }
            }
                        
            
            
        }


        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {


            
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //list of list of sprites
            SpritesForCurrentLevel = new Dictionary<string, ArrayList>();

            //need to make this for only UNIQE items(no dubbles)
            foreach (var item in level.scene.items)
            {
                //if item is ISprite, set up i_sprite as ISprite of item
                if (item is ISprite i_sprite)
                {
                    if (SpritesForCurrentLevel.ContainsKey(i_sprite.Name))
                    {
                        i_sprite.SetUsedSprites(SpritesForCurrentLevel[i_sprite.Name]);
                    }
                    else
                    {
                        SpritesForCurrentLevel[i_sprite.Name] = i_sprite.SetUpAllSprites(GraphicsDevice);
                        i_sprite.SetUsedSprites(SpritesForCurrentLevel[i_sprite.Name]);
                    }
                }


            }
            
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            
            
            





            spriteEffect = new BasicEffect(this.GraphicsDevice);
            spriteEffect.TextureEnabled = true;

            //add player from sprite sheet
            

            FileStream fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/frogTiles/enemy_health_bar.png", FileMode.Open);
            Texture2D spriteAtlas = Texture2D.FromStream(GraphicsDevice, fileStream);

            healthBarSprite = new Sprite
            {
                texture = spriteAtlas,
                sourceRectangle = new Rectangle(x: 1, y: 1, width: 98, height: 16),
                origin = new Vector2(x: 1, y: 1),
                scale = 1f,
                layerDepth = 0.7f,
            };
            fileStream.Dispose();

            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/tornado/tornadoIcon.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(GraphicsDevice, fileStream);

            tornadoIconSprite = new Sprite
            {
                texture = spriteAtlas,
                sourceRectangle = new Rectangle(x: 0, y: 0, width: 255, height: 255),
                origin = new Vector2(x: 0, y: 0),
                scale = 0.2f,
                layerDepth = 0.7f,
            };
            fileStream.Dispose();

            //add tiles from sprite sheet



            tileSprites = level.readMap.SetTileSprites(GraphicsDevice);
            

           
            
            spriteFont = Game.Content.Load<SpriteFont>("test_font");
            
            
            fileStream.Dispose();
            // TODO: use this.Content to load your game content here
        }
        
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }
        
        
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Draw(GameTime gameTime)
        {
            if (!active)
            {
                return;
            }
            GraphicsDevice.Clear(Color.CornflowerBlue);
            
            playerMovment.X = mainPlayer.position.X;
            playerMovment.Y = mainPlayer.position.Y;
            spriteBatch.Begin(sortMode: SpriteSortMode.BackToFront, transformMatrix: camera.worldToScreen);
            float layersDepth = 1f;
            foreach (Dictionary<Vector2, int> layer in level.layers)
            {
                
                foreach (Vector2 key in layer.Keys)
                {
                    
                    /*if (
                    Math.Abs(mainPlayer.position.X - key.X) < GraphicsDevice.Viewport.Width &&
                    Math.Abs(mainPlayer.position.Y - key.Y) < GraphicsDevice.Viewport.Height
                    )*/
                    if (tileSprites[layer[key]] != null)
                        {
                            {
                                spriteBatch.Draw(
                                    texture: tileSprites[layer[key]].texture,
                                    position: key,
                                    sourceRectangle: tileSprites[layer[key]].sourceRectangle,
                                    color: Color.White,
                                    scale: 1,
                                    rotation: 0,
                                    origin: tileSprites[layer[key]].origin,
                                    effects: SpriteEffects.None,
                                    layerDepth: layersDepth);
                            }
                        }
                }
                layersDepth -= 0.01f;

            }
            
            Sprite sprite = new Sprite();
            foreach (var item in level.scene.items)
            {
                if (item is IActive active)
                {

                    if (item is ISprite i_sprite && active.Active)
                    {
                        ArrayList item2 = i_sprite.GetCurrentlyUsedSprites();
                        foreach (var item3 in item2)
                        {
                            sprite = ((Mode)item3).GetSprite();

                            if (sprite.GetType() == typeof(Sprite) && item3 is Mode)
                            {
                                spriteBatch.Draw(
                                    texture: sprite.texture,
                                    position: ((Mode)item3).position,
                                    sourceRectangle: sprite.sourceRectangle,
                                    color: Color.White,
                                    scale: sprite.scale,
                                    rotation: sprite.rotation,
                                    origin: sprite.origin,
                                    effects: SpriteEffects.None,
                                    layerDepth: sprite.layerDepth);
                            }
                        }

                    }
                }
            
                /*if (item is FrogEnemy f)
                {
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.position, new Vector2(f.Radius+50, 0)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.position, new Vector2(0, f.Radius + 50)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.position, new Vector2(-f.Radius - 50, 0)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.position, new Vector2(0, -f.Radius - 50)), Color.Red);
                    
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.sword.position, new Vector2(-f.sword.width / 2, -f.sword.height / 2)), Color.Blue);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.sword.position, new Vector2(f.sword.width / 2, -f.sword.height / 2)), Color.Blue);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.sword.position, new Vector2(-f.sword.width / 2, f.sword.height / 2)), Color.Blue);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(f.sword.position, new Vector2(f.sword.width / 2, f.sword.height / 2)), Color.Blue);
                    
                }
                else if (item is HumanPlayer h)
                {
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(h.position, new Vector2(h.Radius, 0)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(h.position, new Vector2(0, h.Radius)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(h.position, new Vector2(-h.Radius, 0)), Color.Red);
                    spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(h.position, new Vector2(0, -h.Radius)), Color.Red);
                }*/
            }
            /*
            spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(mainPlayer.sword.position, new Vector2(-mainPlayer.sword.width/2, -mainPlayer.sword.height / 2)), Color.Blue);
            spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(mainPlayer.sword.position, new Vector2(mainPlayer.sword.width/2, -mainPlayer.sword.height / 2)), Color.Blue);
            spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(mainPlayer.sword.position, new Vector2(-mainPlayer.sword.width / 2, mainPlayer.sword.height / 2)), Color.Blue);
            spriteBatch.DrawString(spriteFont, String.Format("\""), Vector2.Add(mainPlayer.sword.position, new Vector2(mainPlayer.sword.width/2, mainPlayer.sword.height/2)), Color.Blue);
            */
            spriteBatch.End();
            
            //this.miniMapCamera.zoom = 0.2f;

            spriteBatch.Begin(sortMode: SpriteSortMode.BackToFront, transformMatrix: miniMapCamera.worldToScreen);
                                                                                   //constant of original width
            sprite = healthBarSprite;
            sprite.sourceRectangle.Width = (int)((mainPlayer.Health / mainPlayer.maxHealth) * 128);
            spriteBatch.Draw(
                texture: sprite.texture,
                position: Vector2.Subtract(mainPlayer.Position,   new Vector2(GraphicsDevice.Viewport.Width/2, GraphicsDevice.Viewport.Height/2)),
                sourceRectangle: sprite.sourceRectangle,
                color: Color.White,
                scale: sprite.scale,
                rotation: 0,
                origin: sprite.origin,
                effects: SpriteEffects.None,
                layerDepth: 0.1f);
            
            spriteBatch.DrawString(spriteFont, String.Format("Your HP: {0}", mainPlayer.Health), Vector2.Subtract(mainPlayer.Position, new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2)), Color.Blue);


            float procentTornado = (float)mainPlayer.timeWaitTornado.TotalMilliseconds / 7000;

            sprite = tornadoIconSprite;
            
            spriteBatch.Draw(
                texture: sprite.texture,
                position: Vector2.Add(mainPlayer.Position, new Vector2((GraphicsDevice.Viewport.Width / 2)-(sprite.sourceRectangle.Width*sprite.scale), -(GraphicsDevice.Viewport.Height / 2) )),
                sourceRectangle: new Rectangle(sprite.sourceRectangle.X , sprite.sourceRectangle.Y, (int)(sprite.sourceRectangle.Width*procentTornado), sprite.sourceRectangle.Height),
                color: Color.White,
                scale: sprite.scale,
                rotation: 0,
                origin: sprite.origin,
                effects: SpriteEffects.None,
                layerDepth: 0.1f);


            spriteBatch.Draw(
                texture: sprite.texture,
                position: Vector2.Add(mainPlayer.Position, new Vector2((GraphicsDevice.Viewport.Width / 2) - (sprite.sourceRectangle.Width * sprite.scale), -(GraphicsDevice.Viewport.Height / 2) )) + new Vector2((sprite.sourceRectangle.Width* sprite.scale) * procentTornado, 0),
                sourceRectangle: new Rectangle(sprite.sourceRectangle.X + (int)(sprite.sourceRectangle.Width * procentTornado), sprite.sourceRectangle.Y, sprite.sourceRectangle.Width, sprite.sourceRectangle.Height),
                color: Color.Red,
                scale: sprite.scale,
                rotation: 0,
                origin: sprite.origin,
                effects: SpriteEffects.None,
                layerDepth: 0.1f);
                
            spriteBatch.End();
            
            base.Draw(gameTime);
            
        }
    }
}
