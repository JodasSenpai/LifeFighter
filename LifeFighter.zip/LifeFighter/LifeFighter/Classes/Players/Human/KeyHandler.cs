﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LifeFighter.Classes.Players.Human
{
    public partial class KeyHandler : Form
    {

        public KeyHandler()
        {
            
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine(String.Format("Keypressed: {0}", e.KeyCode));
            base.OnKeyDown(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine(String.Format("Keypressed: {0}", e.KeyChar));
            base.OnKeyPress(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
        }
    }
}
