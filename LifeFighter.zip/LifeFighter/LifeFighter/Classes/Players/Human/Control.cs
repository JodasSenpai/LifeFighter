﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter.Classes.Players.Human
{
    class Control : IActive
    {
        public bool active;

        public Control()
        {
            active = true;
        }

        public bool Active { get => active; set => active = value; }

        public void Update(GameTime gameTime)
        {
            if (!active)
            {
                return;
            }

        }
    }
}
