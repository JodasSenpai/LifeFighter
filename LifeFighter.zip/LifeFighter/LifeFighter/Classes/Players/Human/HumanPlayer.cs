﻿using LifeFighter.Classes.Scene.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Artificial;
using Exspress.Classes.Scene.Objects;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using Exspress.Classes.Graphics;
using LifeFighter.Classes.Graphics;

namespace LifeFighter.Classes.Players.Human
{
    public class HumanPlayer : Player,IHealth, ICustomCollider,ISprite,IActive
    {
        public Vector2 distance;
        
        Vector2 movment;
        
        float speed;
        public Sword sword;
        public bool active;
        public bool tmp;
        public bool moving;
        public bool attacked;
        public bool bookOpen;
        public bool tornado;
        public int direction;
        public int directionAttack;
        public TimeSpan timeMovment;
        public TimeSpan timeAttack;
        public TimeSpan timeBook;
        public TimeSpan timeTornado;
        public TimeSpan timeWaitTornado;
        TimeSpan timeAddMovment;
        TimeSpan timeAddBook;
        TimeSpan timeAddTornado;
        TimeSpan timeAddWaitTornado;
        TimeSpan timeAddAttack;
        Dictionary<int, Action> Dict;
        Dictionary<string, Mode> modeSprites;
        ArrayList currentlyUsedModesNames;

        float health;
        public float Health { get => health; set => health = value; }
        string name;
        public string Name { get => name; set => name = value; }
        public bool Active { get => active; set => active = value; }

        public float maxHealth;
        public HumanPlayer(Vector2 position) : base(position)
        {

            tmp = true;
            active = true;
            Name = "HumanPlayer";
            this.speed = 2.1f;
            currentlyUsedModesNames = new ArrayList();
            currentlyUsedModesNames.Add("frog");
            this.sword = new Sword(position);
            this.movment = position;
            timeMovment = new TimeSpan(0, 0, 0, 0, 0);
            timeAttack = new TimeSpan(0, 0, 0, 0, 0);
            timeBook = new TimeSpan(0, 0, 0, 0, 0);
            timeTornado = new TimeSpan(0, 0, 0, 0, 0);
            timeWaitTornado = new TimeSpan(0, 0, 0, 0, 0);
            timeAddMovment = new TimeSpan(0, 0, 0, 0, 100);
            timeAddAttack = new TimeSpan(0, 0, 0, 0, 200);
            timeAddBook = new TimeSpan(0, 0, 0, 0, 30);
            timeAddTornado = new TimeSpan(0, 0, 0, 0, 50);
            timeAddWaitTornado = new TimeSpan(0, 0, 0, 0, 50);
            moving = false;
            bookOpen = false;
            tornado = false;
            direction = 1;
            Dict = new Dictionary<int, Action>();
            modeSprites = new Dictionary<string, Mode>();
            maxHealth = 100;
            Health = maxHealth;
            
            Dict.Add((int)Keys.A, value: MoveLeft);
            Dict.Add(((int)Keys.A + (int)Keys.W), value: MoveLeftUp);
            Dict.Add(((int)Keys.A + (int)Keys.S), value: MoveLeftDown);
            Dict.Add((int)Keys.W, value: MoveUp);
            Dict.Add((int)Keys.D, value: MoveRight);
            Dict.Add(((int)Keys.D + (int)Keys.W), value: MoveRightUp);
            Dict.Add(((int)Keys.D + (int)Keys.S), value: MoveRightDown);
            Dict.Add((int)Keys.S, value: MoveDown);

            //Dict.Add((int)Keys.Escape, value: game.Exit);
        }

        void MoveRight()
        {   
            movment = position + new Vector2(speed,0);
            directionAttack = 2;
            direction = 2;
            
        }
        void MoveRightUp()
        {
            movment = position + new Vector2(speed, -speed);
            directionAttack = 2;
            direction = 2;
            
        }
        void MoveRightDown()
        {
            movment = position + new Vector2(speed , speed );
            directionAttack = 2;
            direction = 2;
            
        }
        void MoveLeft()
        {
            
            movment = position + new Vector2(-speed, 0);
            directionAttack = 1;
            direction = 3;
            

        }
        void MoveLeftUp()
        {

            movment = position + new Vector2(-speed , -speed);
            directionAttack = 1;
            direction = 3;
            
        }
        void MoveLeftDown()
        {

            movment = position + new Vector2(-speed , speed);
            directionAttack = 1;
            direction = 3;
            
        }
        void MoveUp()
        {
            
            movment = position + new Vector2(0, -speed);
            directionAttack = 3;
            direction = 0;
            
        }
        void MoveDown()
        {

            movment = position + new Vector2(0, speed);
            directionAttack = 0;
            direction = 1;
            
        }

        public void Update(GameTime gameTime)
        {
            if (!active)
            {
                return;
            }
            KeyboardState keyState = Keyboard.GetState();
            MouseState mouseState = Mouse.GetState();
            Keys[] pressedKeys = keyState.GetPressedKeys();
            ButtonState pressedMouse = mouseState.LeftButton;
            currentlyUsedModesNames.Clear();
            currentlyUsedModesNames.Add("human");
            
            if (position.X < 0 || position.Y < 0 && tmp == true)
            {
                tmp = false;
                //SoundEngine.soundEffects[2].CreateInstance().Play();

            }

            //keyboard pressed   && !attacked
            if (pressedKeys.Any() )
            {
                
                if (Dict.ContainsKey((int)pressedKeys[0]))
                {
                    if (pressedKeys.Length == 1)
                    {
                        Dict[(int)pressedKeys[0]].Invoke();
                        moving = true;
                    }
                    else if (pressedKeys.Length == 2 && Dict.ContainsKey((int)pressedKeys[0] + (int)pressedKeys[1]))
                    {
                        Dict[(int)pressedKeys[0]+ (int)pressedKeys[1]].Invoke();
                        moving = true;
                    }
                    
                    timeMovment += timeAddMovment;
                    if (timeMovment.TotalMilliseconds > 1900 || timeMovment.TotalMilliseconds < 100)
                    {
                        timeAddMovment = timeAddMovment.Negate();
                        timeMovment += timeAddMovment;
                    }
                }
                if(pressedKeys[0] == Keys.E)
                {
                    bookOpen = true;
                }
                if (bookOpen && pressedKeys[0] == Keys.R && timeTornado.TotalMilliseconds == 0 && timeWaitTornado.TotalMilliseconds >= 7000)
                {
                    modeSprites["tornado"].position = this.Position + new Vector2(0, -40);
                    tornado = true;
                    timeWaitTornado = new TimeSpan(0, 0, 0, 0, 0);
                }

            }
            else
            {
                timeMovment = new TimeSpan(0, 0, 0, 0, 0);
                moving = false;

            }
            modeSprites["human"].time = timeMovment;
            modeSprites["human"].direction = direction;
            modeSprites["human"].position = position;
            //mouse pressed
            if (pressedMouse == ButtonState.Pressed)
            {
                attacked = true;
                //if attacking up
                tmp = true;
                sword.position = directionAttack == 3 ? sword.position = position - new Vector2(0, 2): sword.position = position - new Vector2(0, -7);
                if(directionAttack == 3)
                {
                    sword.position = position - new Vector2(0, 7);
                }
                else if(directionAttack == 0)
                {
                    sword.position = position - new Vector2(0, -7);
                }
                else if (directionAttack == 1)
                {
                    sword.position = position - new Vector2(7, -7);
                }
                else if (directionAttack == 2)
                {
                    sword.position = position - new Vector2(-7, -7);
                }
                sword.DirectionChange(directionAttack);
            }
            
            

            if (attacked)
            {
                
                currentlyUsedModesNames.Add("sword");
                modeSprites["sword"].time = timeAttack;
                modeSprites["sword"].direction = directionAttack;
                modeSprites["sword"].position = sword.position;
                timeAttack += timeAddAttack;
                if (timeAttack.TotalMilliseconds >= 3000)
                {
                    currentlyUsedModesNames.Remove("sword");
                    //SoundEngine.soundEffects[0].CreateInstance().Play();
                    attacked = false;
                    timeAttack = new TimeSpan(0, 0, 0, 0, 0);
                    
                }
                


            }
            else if (bookOpen)
            {
                currentlyUsedModesNames.Add("book");
                modeSprites["book"].time = timeBook;
                modeSprites["book"].direction = directionAttack;
                if(directionAttack == 0)
                {
                    modeSprites["book"].position = this.Position + new Vector2(0, 40);
                }
                else if (directionAttack == 1)
                {
                    modeSprites["book"].position = this.Position + new Vector2(-40, 0);
                }
                else if (directionAttack == 2)
                {
                    modeSprites["book"].position = this.Position + new Vector2(40, 0);
                }
                else if (directionAttack == 3)
                {
                    modeSprites["book"].position = this.Position + new Vector2(0, -40);
                }
                
                timeBook += timeAddBook;
                if (timeBook.TotalMilliseconds >= 3000)
                {
                    currentlyUsedModesNames.Remove("book");
                    bookOpen = false;
                    timeBook = new TimeSpan(0, 0, 0, 0, 0);
                }
            }

            if (tornado)
            {
                currentlyUsedModesNames.Add("tornado");
                modeSprites["tornado"].time = timeTornado;
                modeSprites["tornado"].direction = 0;
                if (directionAttack == 0)
                {
                    modeSprites["tornado"].position += new Vector2(0, 5);
                }
                else if (directionAttack == 1)
                {
                    modeSprites["tornado"].position += new Vector2(-5, 0);
                }
                else if (directionAttack == 2)
                {
                    modeSprites["tornado"].position += new Vector2(5, 0);
                }
                else if (directionAttack == 3)
                {
                    modeSprites["tornado"].position += new Vector2(0, -5);
                }
                
                timeTornado += timeAddTornado;
                if (timeTornado.TotalMilliseconds >= 3000)
                {
                    currentlyUsedModesNames.Remove("tornado");
                    tornado = false;
                    timeTornado = new TimeSpan(0, 0, 0, 0, 0);
                    
                }
            }
            else if (timeWaitTornado.TotalMilliseconds < 7000)
            {
                timeWaitTornado += timeAddWaitTornado;
            }

            distance = Vector2.Subtract(movment, position);
            
            if ((float)gameTime.ElapsedGameTime.TotalMilliseconds != 0)
            {
                Velocity = Vector2.Multiply(distance, 1.0f / ((float)gameTime.ElapsedGameTime.TotalMilliseconds));
            }
            
        }

        public bool CollidingWithItem(object item)
        {
            return true;
            
        }

        public void CollidedWithItem(object item)
        {
           
            if (item is Sword)
            {
                Health -= 1;
                Sword s = (Sword)item;
                s.collided = true;
            }            
            
            
        }

        public ArrayList GetCurrentlyUsedSprites()
        {
            int c = currentlyUsedModesNames.Count;
            ArrayList returnModes = new ArrayList(c);
            for (int i = 0; i < c; i++)
            {
                returnModes.Add(modeSprites[(string)currentlyUsedModesNames[i]]);
            }
            return returnModes;
        }
        public void SetUsedSprites(ArrayList list)
        {

            modeSprites["human"] = new Mode(((Mode)list[0]).sprites);
            
            modeSprites["sword"] = new Mode(((Mode)list[1]).sprites);

            modeSprites["book"] = new Mode(((Mode)list[2]).sprites);

            modeSprites["tornado"] = new Mode(((Mode)list[3]).sprites);
                       
        }

        public ArrayList SetUpAllSprites(GraphicsDevice graphicDevice)
        {
            ArrayList list = new ArrayList();
            // need to create spritesheet for each uniqe enemy, might not be the optimal solution but it is a start
            FileStream fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/modernGuyTiles/modernGuySheet.png", FileMode.Open);
            Texture2D spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            /*
             * 
             * 0 -> human sprite
             * 1 -> sword sprite
             * 2 -> book sprite
             *
             */

            //since i'll try to make spritesheet of all the sprites FrogEnemy uses, The number right now are INCORRECT!!!
            //add humanSprite <- 0
            
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            Mode playerSprite = new Mode();
            int row = 1;
            int column = 1;
            for (int i = 0; i <= 3; i++)
            {
                column = 1;
                int time = 0;
                AnimatedSprite a = new AnimatedSprite();
                a.SetWithLoopDuration(new TimeSpan(0, 0, 0, 2, 0));
                playerSprite.sprites.Add(a);
                for (int j = 0; j <= 3; j++)
                {
                    Sprite sprite = new Sprite
                    {
                        texture = spriteAtlas,
                        sourceRectangle = new Rectangle(x: column, y: row, width: 24, height: 24),
                        origin = new Vector2(x: 11, y: 11),
                        scale = 2,
                        layerDepth = 0.7f,
                        rotation = 0f,
                        spriteEffect = SpriteEffects.None
                    };
                    AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time));
                    ((AnimatedSprite)(playerSprite.sprites[i])).AddFrame(frame);
                    column += 26;
                    time += 500;
                }
                row += 26;
            }
            fileStream.Dispose();

            list.Add(playerSprite);
            //INCORRECT numbers involve every sprite!!!!
            //add sword <- 1
            Mode swordSprite = new Mode();
            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/sword/sword3try/swordsheet.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            row = 1;
            column = 1;
            for (int i = 0; i <= 3; i++)
            {
                int time = 0;
                AnimatedSprite a = new AnimatedSprite();
                a.SetWithLoopDuration(new TimeSpan(0, 0, 0, 3, 0));
                swordSprite.sprites.Add(a);
                for (int j = 0; j <= 2; j++)
                {
                    float depth = 0.8f;
                    if (i == 0) {
                        depth = 0.4f;
                    }
                    Sprite sprite = new Sprite
                    {
                        texture = spriteAtlas,
                        sourceRectangle = new Rectangle(x: column, y: row, width: 192, height: 154),
                        origin = new Vector2(x: 96, y: 78),
                        scale = 1,
                        rotation = 0f,
                        layerDepth = depth,
                    };
                    AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time));
                    ((AnimatedSprite)(swordSprite.sprites[i])).AddFrame(frame);

                    time += 1000;
                    column += 196;
                }


            }
            fileStream.Dispose();
            list.Add(swordSprite);



            Mode bookSprite = new Mode();
            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/book/booksheet.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            row = 1;
            
            for (int i = 0; i <= 3; i++)
            {
                column = 1;
                int time2 = 0;
                AnimatedSprite a2 = new AnimatedSprite();
                a2.SetWithLoopDuration(new TimeSpan(0, 0, 0, 3, 0));
                bookSprite.sprites.Add(a2);
                for (int j = 0; j <= 40; j++)
                {
                    float depth = 0.8f;
                    Sprite sprite = new Sprite
                    {
                        texture = spriteAtlas,
                        sourceRectangle = new Rectangle(x: column, y: row, width: 28, height: 35),
                        origin = new Vector2(x: 14, y: 17),
                        scale = 1,
                        rotation = 0f,
                        layerDepth = depth,
                    };
                    AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time2));
                    ((AnimatedSprite)(bookSprite.sprites[i])).AddFrame(frame);

                    time2 += 73;
                    column += 34;
                }
                row += 34;
            }


            
            fileStream.Dispose();
            list.Add(bookSprite);

            Mode tornadoSprite = new Mode();
            fileStream = new FileStream("..\\..\\..\\..\\/Resources/mockpictures/tornado/tornadosheet.png", FileMode.Open);
            spriteAtlas = Texture2D.FromStream(graphicDevice, fileStream);
            row = 1;
            column = 1;
            
            int time3 = 0;
            AnimatedSprite a3 = new AnimatedSprite();
            a3.SetWithLoopDuration(new TimeSpan(0, 0, 0, 3, 0));
            tornadoSprite.sprites.Add(a3);
            for (int j = 0; j <= 15; j++)
            {
                float depth = 0.8f;                    
                Sprite sprite = new Sprite
                {
                    texture = spriteAtlas,
                    sourceRectangle = new Rectangle(x: column, y: row, width: 128, height: 128),
                    origin = new Vector2(x: 64, y: 64),
                    scale = 1,
                    rotation = 0f,
                    layerDepth = depth,
                };
                AnimatedSpriteFrame frame = new AnimatedSpriteFrame(sprite, new TimeSpan(0, 0, 0, 0, time3));
                ((AnimatedSprite)(tornadoSprite.sprites[0])).AddFrame(frame);

                time3 += 187;
                column += 130;
            }


            
            fileStream.Dispose();
            list.Add(tornadoSprite);


            return list;
        }
    }
}
