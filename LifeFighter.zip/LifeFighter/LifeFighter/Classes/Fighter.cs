﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Collections;
using LifeFighter.Classes.Scene.Levels;
using Artificial;
using LifeFighter.Classes.Scene;

namespace LifeFighter.Classes
{
    class Fighter : Game
    {
        GraphicsDeviceManager graphics;
        Gameplay currentGameplay;
        

        FpsComponent fps;

        ArrayList levels;


        public Fighter()
        {
            
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 1920;
            graphics.PreferredBackBufferHeight = 1080;
            Content.RootDirectory = "Resources";
            
        }
        protected override void Initialize()
        {
            levels = new ArrayList();
            levels.Add(new IntroLevel(this));
            levels.Add(new HouseLevel(this));
            levels.Add(new VidLevel(this));

            LoadLevel((IntroLevel)levels[0]);

            base.Initialize();
        }
        public void LoadLevel(Level level)
        {   
            currentGameplay = new Gameplay(this, level);
            currentGameplay.SingleplayerMode();
            this.Components.Add(currentGameplay);

            fps = new FpsComponent(this);            
            this.Components.Add(fps);
        }

        protected override void Update(GameTime gameTime)
        {


            if (((Level)levels[0]).end)
            {
                this.Components.Remove(currentGameplay);
                LoadLevel((HouseLevel)levels[1]);
            }
            
            base.Update(gameTime);
        }
    }
}
