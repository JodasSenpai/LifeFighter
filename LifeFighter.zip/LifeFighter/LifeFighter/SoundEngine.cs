﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeFighter
{
    class SoundEngine : GameComponent
    {
        public static List<SoundEffect> soundEffects;
        public SoundEngine(Game game) : base(game)
        {
            soundEffects = new List<SoundEffect>();
            soundEffects.Add(Game.Content.Load<SoundEffect>("sword-swipe"));
            soundEffects.Add(Game.Content.Load<SoundEffect>("frog-death"));
            soundEffects.Add(Game.Content.Load<SoundEffect>("wall-hit"));

        }
    }
}
