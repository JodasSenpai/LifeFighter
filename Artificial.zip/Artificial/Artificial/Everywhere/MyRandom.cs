﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Artificial.Everywhere
{
    public static class MyRandom
    {
        public static Random rnd = new Random();
    }
}
