﻿using Microsoft.Xna.Framework;

namespace Artificial.Everywhere
{
    class Rectangle_Extensions
    {
        public bool ContainsVector(Rectangle rec, Vector2 vec)
        {            
            return ((vec.X >= rec.X && vec.X <= rec.X + rec.Width &&
            vec.Y >= rec.Y && vec.Y <= rec.Y + rec.Height));
        }
    }
}
