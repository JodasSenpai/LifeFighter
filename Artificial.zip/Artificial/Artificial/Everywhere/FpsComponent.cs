﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Artificial
{
    public class FpsComponent : GameComponent
    {
        int fpsCounter;
        DateTime countStart;

        public FpsComponent(Game game):base(game)
        {
            fpsCounter = 0;
        }

        public override void Initialize()
        {
            this.countStart = DateTime.Now;
            base.Initialize();
        }

        public override void Update(GameTime gameTime)
        {
            fpsCounter++;
            DateTime currentTime = DateTime.Now;


            if ((currentTime.Second - countStart.Second) > 1)
            {
                
                System.Diagnostics.Debug.WriteLine(String.Format("FPS counter: {0}", fpsCounter));
                

                fpsCounter = 0;
                countStart = currentTime;
                if (gameTime.IsRunningSlowly)
                {
                    System.Diagnostics.Debug.WriteLine("Game is so slow");
                }
            }
            base.Update(gameTime);
        }
    }
}
